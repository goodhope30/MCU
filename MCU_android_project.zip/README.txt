MCU Android app (WebView). The dashboard is in app/src/main/assets/index.html and works offline.

Option A - Android Studio: File > Open this folder > Build > Build APK(s). Copy app-debug.apk to the phone and install.
Option B - GitHub (no installs): create a free repository, upload all these files (keep the .github folder), open the Actions tab,
run "Build APK", then download "MCU-apk" from the finished run.
To update the dashboard later, replace app/src/main/assets/index.html and build again.
